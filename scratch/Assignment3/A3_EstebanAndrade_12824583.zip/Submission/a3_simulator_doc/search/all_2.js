var searchData=
[
  ['controlfriendly',['controlFriendly',['../classSimulator.html#adb1cff57466c3b03fd738036cb9cee63',1,'Simulator']]],
  ['currentgoalpose',['currentGoalPose',['../structAircraft.html#a350988ee89dd6631da4e991844a98975',1,'Aircraft']]]
];
