var searchData=
[
  ['timer',['timer',['../structAircraft.html#a256a704e2dbf859d95d4eb28b0e02aa3',1,'Aircraft']]],
  ['timestamp',['timestamp',['../structRangeBearingStamped.html#a7803974f4f1e9de3469b21dae3289530',1,'RangeBearingStamped::timestamp()'],['../structRangeVelocityStamped.html#a3fec5547c45ed9c80e69ff7e38d9ef99',1,'RangeVelocityStamped::timestamp()']]],
  ['trail',['trail',['../structAircraft.html#a11f949f7f9f22bae298b9c821fccf928',1,'Aircraft']]]
];
