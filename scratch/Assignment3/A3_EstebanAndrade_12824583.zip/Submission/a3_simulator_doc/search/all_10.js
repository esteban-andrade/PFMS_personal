var searchData=
[
  ['y',['y',['../structGlobalOrd.html#af9f9e1597f7373a92ce693c10acec8a5',1,'GlobalOrd']]]
];
